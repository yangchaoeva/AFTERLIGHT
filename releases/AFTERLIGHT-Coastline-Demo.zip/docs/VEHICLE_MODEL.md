# Original procedural vehicle models

`src/vehicle.js` generates three original cars entirely from authored geometry. No manufacturer CAD, ripped game models, or downloaded car assets are used. The module imports Three.js and its MIT-licensed geometry helpers.

## Design

- AURORA GT: long hood, sculpted wheel shoulders, fastback cabin, flush rear lip, silver forged wheels.
- KASUMI R: shorter wheelbase/body, taller compact cabin, champagne wheels, fixed club-sport wing.
- VESPER X: lower cabin shifted forward, wider body, rear intake channels, engine-deck vents and wing.

All use the same geometric construction vocabulary, but their dimensions, roofline, stance, vents and aerodynamic elements differ. They are stylized original sports cars, not production-ready automotive CAD.

The body has a continuously sampled crowned upper surface and lower side panels whose boundary is cut around the wheels. Separate curved windshield, roof, rear glass and side glazing preserve cabin depth. Bucket seats, dashboard, steering wheel, console and contrast stitching are present behind the glass.

Near-field detail includes multiple optical blades per headlamp, rear light sculptures, original chevron badges, panel gaps, mirror stalks and optical faces, hood shut lines, wheel-arch trim, intake vanes, side vents, diffuser fins and hollow exhaust tips.

Wheels have lathed crowned tires, bead/sidewall rings, embossed shoulder sipes, forged spokes, rotor discs, drilled-hole geometry, lug nuts, separate calipers and central caps. Rotating parts are grouped separately from steering pivots and fixed calipers.

## API

```js
import { CAR_SPECS, createCar, updateCar } from './vehicle.js';
const car = createCar({ model: 'aurora', color: '#e8a64b', detail: 'high' });
updateCar(car, { steer: 0.2, speed: 30, brake: 0, time: elapsed, dt });
```

Coordinates are metres, +Z forward, +Y up, X lateral, ground Y=0. Car origin is midway between axles. Speed is m/s. Steering is normalized -1 to 1. Brake is 0 to 1. `userData` exposes `wheels`, `body`, `paint`, `brakeLights`, `spec`, `length`, and `halfWidth`.

Static geometry is merged by material, and material instances are shared throughout a car. Low-detail opponents reduce tessellation and omit tread, drilled holes, lug nuts and stitching. Both versions retain actual curved bodywork, wheel arches, glazing and animated wheels. Environment maps and directional lighting are supplied by the scene; they are essential to showing paint and glass correctly.

Node geometry checks: high detail uses 45 mesh batches and approximately 92,000–98,000 triangles per car; low detail uses 32 mesh batches and approximately 56,000–62,000 triangles. All three models were instantiated at both detail levels, checked for non-finite vertex positions, and advanced through steering/wheel/brake animation. These counts exclude shadow and transparent-material render passes and are not a measured frame-rate claim.

Do not dispose a single wheel material in isolation: it is shared by other parts of that car. Dispose unique geometry and material objects once when permanently unloading the complete vehicle.
