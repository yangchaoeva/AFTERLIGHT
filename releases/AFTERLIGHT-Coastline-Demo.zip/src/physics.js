import * as THREE from 'three';
import { wrap01 } from './track.js';

export const VEHICLES = {
  aurora: { name:'曙光 GT', label:'AURORA GT', layout:'AWD · GRAND TOURER', power:520, mass:1540, topSpeed:82, acceleration:10.6, grip:15.2, agility:1, color:'#b8d9cf' },
  kasumi: { name:'雾刃 R', label:'KASUMI R', layout:'RWD · LIGHTWEIGHT', power:410, mass:1210, topSpeed:77, acceleration:10.1, grip:16.4, agility:1.10, color:'#ebaa66' },
  vesper: { name:'暮星 X', label:'VESPER X', layout:'MR · SUPERCAR', power:640, mass:1435, topSpeed:88, acceleration:11.7, grip:14.3, agility:.92, color:'#b4bbc7' },
};
export const angleDelta = (a,b) => Math.atan2(Math.sin(a-b),Math.cos(a-b));
const damp=(a,b,k,dt)=>THREE.MathUtils.lerp(a,b,1-Math.exp(-k*dt));
export const steeringLimit = speed => .50/(1+Math.abs(speed)*.075+speed*speed*.003);

export function createDriver(track,{id='player',name='你',model='aurora',t=0,lane=0,isPlayer=false}={}) {
  const s=track.sample(t);
  return {id,name,model,isPlayer,position:s.position.clone().addScaledVector(s.right,lane),
    heading:s.heading,velocityHeading:s.heading,speed:0,steer:0,throttle:0,brake:0,
    slip:0,roll:0,pitch:0,t:wrap01(t),startT:t,progress:0,offset:lane,
    checkpoint:1,lastCheckpointT:wrap01(t),checkpointsPassed:0,lap:0,lapTimes:[],
    lastLapTime:0,finishTime:null,penalty:0,collisionCooldown:0,offroadTime:0,
    targetLane:lane,preferredLane:lane,stuckTime:0,respawns:0,distance:0};
}

export function resetDriver(driver,track,t=driver.t,lane=0) {
  const s=track.sample(t);
  driver.position.copy(s.position).addScaledVector(s.right,lane);
  driver.heading=s.heading;driver.velocityHeading=s.heading;
  driver.speed=0;driver.steer=0;driver.slip=0;driver.offset=lane;driver.t=wrap01(t);
  driver.offroadTime=0;driver.stuckTime=0;
}

export function stepDriver(d,input,track,dt) {
  const spec=VEHICLES[d.model]||VEHICLES.aurora;
  d.throttle=THREE.MathUtils.clamp(input.throttle||0,0,1);
  d.brake=THREE.MathUtils.clamp(input.brake||0,0,1);
  d.steer=damp(d.steer,THREE.MathUtils.clamp(input.steer||0,-1,1),input.digital?5:10,dt);
  const v=Math.max(0,d.speed),oldSpeed=v;
  let a=spec.acceleration*(1-.68*Math.min(1,v/spec.topSpeed))*d.throttle;
  a-=1.0+v*v*.00034+25*d.brake;
  if(input.handbrake)a-=7;
  if(Math.abs(d.offset)>track.width/2-.7)a-=4+v*.10;
  d.speed=THREE.MathUtils.clamp(v+a*dt,0,spec.topSpeed);
  const wheelAngle=d.steer*steeringLimit(v);
  const rawYaw=v*Math.tan(wheelAngle)/2.72*spec.agility;
  const maxYaw=spec.grip/Math.max(v,7)*(input.handbrake?1.18:1);
  const yaw=THREE.MathUtils.clamp(rawYaw,-maxYaw,maxYaw);
  d.heading+=yaw*dt;
  const lag=input.handbrake?2.5:(d.model==='kasumi'?9:13);
  d.velocityHeading+=angleDelta(d.heading,d.velocityHeading)*(1-Math.exp(-lag*dt));
  d.slip=Math.min(1,Math.abs(angleDelta(d.heading,d.velocityHeading))*5+(input.handbrake&&v>8?.4:0));
  d.speed*=1-Math.min(.23,d.slip*.09)*dt;
  d.position.x+=Math.sin(d.velocityHeading)*d.speed*dt;
  d.position.z+=Math.cos(d.velocityHeading)*d.speed*dt;
  const nearest=track.nearest(d.position,d.t);
  let delta=nearest.t-d.t;
  if(delta>.5)delta-=1;
  if(delta<-.5)delta+=1;
  d.progress+=delta;
  d.distance+=Math.max(0,delta)*track.length;
  d.t=nearest.t;d.offset=nearest.offset;
  d.position.y=nearest.position.y;
  const barrier=track.width/2-.96;
  if(Math.abs(d.offset)>barrier) {
    const side=Math.sign(d.offset);
    d.position.addScaledVector(nearest.right,-side*(Math.abs(d.offset)-barrier));
    const headingError=angleDelta(d.heading,nearest.heading);
    d.speed*=1-Math.min(.7,Math.abs(headingError)*.9)*Math.min(1,dt*12);
    d.heading+=angleDelta(nearest.heading,d.heading)*Math.min(1,dt*4);
    d.velocityHeading=d.heading;d.offset=side*barrier;
    d.collisionCooldown=.2;
  }
  d.collisionCooldown=Math.max(0,d.collisionCooldown-dt);
  d.roll=damp(d.roll,-yaw*d.speed*.0016,8,dt);
  d.pitch=damp(d.pitch,(d.speed-oldSpeed)/dt*.002,8,dt);
  d.stuckTime=d.speed<2&&d.throttle>.2?d.stuckTime+dt:0;
  return nearest;
}

export function aiControls(d,track,drivers,difficulty='normal') {
  const skill={easy:.70,normal:.84,hard:.98}[difficulty]||.84;
  const s=track.sample(d.t),speed=d.speed;
  const ahead=Math.max(12,speed*.85);
  const aim=track.sample(d.t+ahead/track.length);
  let lane=d.preferredLane;
  let desired=(VEHICLES[d.model].topSpeed-8)*skill;
  for(let dist=8;dist<=120;dist+=14){
    const c=Math.abs(track.sample(d.t+dist/track.length).curvature);
    const safe=Math.sqrt((VEHICLES[d.model].grip*.78)/Math.max(c,.001));
    const brakingReach=Math.sqrt(safe*safe+2*13*dist);
    desired=Math.min(desired,brakingReach*skill);
  }
  for(const other of drivers){
    if(other===d)continue;
    const gap=(other.position.x-d.position.x)*s.tangent.x+(other.position.z-d.position.z)*s.tangent.z;
    if(gap>0&&gap<34&&Math.abs(other.offset-d.offset)<2.3){
      const side=other.offset>0?-1:1;
      lane=side*3.6;
      if(gap<8)desired=Math.min(desired,Math.max(12,other.speed-2));
    }
  }
  d.targetLane=damp(d.targetLane,lane,1.4,1/60);
  const target=aim.position.addScaledVector(aim.right,d.targetLane);
  const targetHeading=Math.atan2(target.x-d.position.x,target.z-d.position.z);
  const error=angleDelta(targetHeading,d.heading);
  const curvature=2*Math.sin(error)/ahead;
  const steer=THREE.MathUtils.clamp(Math.atan(2.72*curvature)/steeringLimit(speed),-1,1);
  return {steer,throttle:THREE.MathUtils.clamp((desired-speed)*.45,0,1),brake:THREE.MathUtils.clamp((speed-desired)*.13,0,1)};
}

export function resolveCars(drivers,track,dt) {
  for(let i=0;i<drivers.length;i++)for(let j=i+1;j<drivers.length;j++){
    const a=drivers[i],b=drivers[j];
    const dx=b.position.x-a.position.x,dz=b.position.z-a.position.z;
    if(dx*dx+dz*dz>24)continue;
    const forward=new THREE.Vector3(Math.sin(a.heading),0,Math.cos(a.heading));
    const right=new THREE.Vector3(forward.z,0,-forward.x);
    const along=dx*forward.x+dz*forward.z,side=dx*right.x+dz*right.z;
    if(Math.abs(along)>4.3||Math.abs(side)>1.88)continue;
    if(Math.abs(along)/4.3>Math.abs(side)/1.88){
      const n=Math.sign(along)||1,push=(4.3-Math.abs(along))*.5;
      a.position.addScaledVector(forward,-n*push);b.position.addScaledVector(forward,n*push);
      const rear=n>0?a:b,front=n>0?b:a;
      if(rear.speed>front.speed){const mean=(rear.speed+front.speed)*.5;rear.speed=mean*.94;front.speed=mean;}
    } else {
      const n=Math.sign(side)||1,push=(1.88-Math.abs(side))*.5;
      a.position.addScaledVector(right,-n*push);b.position.addScaledVector(right,n*push);
      a.speed*=1-.18*dt;b.speed*=1-.18*dt;
    }
    a.collisionCooldown=.15;b.collisionCooldown=.15;
  }
}

export function updateRaceProgress(d,track,raceTime,totalLaps) {
  if(d.finishTime!==null)return null;
  // Sequential gates. A forward crossing is required; reversing over the line never earns a lap.
  const segment=track.length/track.checkpoints;
  const nextDistance=d.checkpoint*segment;
  const absolute=(d.startT+d.progress)*track.length;
  if(absolute>=nextDistance&&absolute<nextDistance+segment*.6){
    d.checkpoint++;d.checkpointsPassed++;
    if(d.checkpointsPassed%track.checkpoints===0){
      d.lap++;
      d.lapTimes.push(raceTime-d.lastLapTime);
      d.lastLapTime=raceTime;
      if(d.lap>=totalLaps){d.finishTime=raceTime+d.penalty;return 'finish';}
      return 'lap';
    }
  }
  return null;
}

export function ranking(drivers) {
  return [...drivers].sort((a,b)=>{
    if(a.finishTime!==null&&b.finishTime!==null)return a.finishTime-b.finishTime;
    if(a.finishTime!==null)return -1;if(b.finishTime!==null)return 1;
    return (b.startT+b.progress)-(a.startT+a.progress);
  });
}
