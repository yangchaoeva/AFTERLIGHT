import * as THREE from 'three';

export const wrap01 = t => ((t % 1) + 1) % 1;
export const TRACK_NAME = '金潮海岸';

export function createTrack() {
  // One authored circuit: the low coast, the inland climbing esses and the viaduct.
  const knots = [
    [-300, 21, -300], [-130, 23, -365], [95, 31, -360],
    [275, 40, -260], [350, 48, -90], [230, 54, 55],
    [310, 48, 210], [200, 38, 360], [15, 30, 395],
    [-190, 23, 345], [-330, 20, 225], [-420, 18, 45],
    [-415, 20, -135],
  ].map(p => new THREE.Vector3(...p));
  const curve = new THREE.CatmullRomCurve3(knots, true, 'centripetal');
  curve.arcLengthDivisions = 5000;
  const length = curve.getLength();
  const count = 2400;
  const positions = Array.from({length:count}, (_,i)=>curve.getPointAt(i/count));
  const tangents = Array.from({length:count}, (_,i)=>curve.getTangentAt(i/count));
  const rights = tangents.map(v=>new THREE.Vector3(v.z,0,-v.x).normalize());
  const ups = tangents.map((v,i)=>new THREE.Vector3().crossVectors(v,rights[i]).normalize());
  const curvatures = tangents.map((v,i)=>{
    const prev=tangents[(i-4+count)%count], next=tangents[(i+4)%count];
    const angle = Math.atan2(prev.z*next.x-prev.x*next.z,prev.x*next.x+prev.z*next.z);
    return angle/(length*8/count);
  });
  const v=new THREE.Vector3();
  function sample(t) {
    const f=wrap01(t)*count, i=Math.floor(f)%count,j=(i+1)%count,a=f-i;
    const tangent=tangents[i].clone().lerp(tangents[j],a).normalize();
    const right=rights[i].clone().lerp(rights[j],a).normalize();
    return {position:positions[i].clone().lerp(positions[j],a),tangent,right,
      up:new THREE.Vector3().crossVectors(tangent,right).normalize(),
      heading:Math.atan2(tangent.x,tangent.z),curvature:THREE.MathUtils.lerp(curvatures[i],curvatures[j],a)};
  }
  function nearest(position, hint=null) {
    let best=0,bestD=Infinity;
    const center=hint===null?0:Math.round(wrap01(hint)*count);
    const span=hint===null?count:90;
    const step=hint===null?8:2;
    for(let n=hint===null?0:-span;n<(hint===null?count:span);n+=step){
      const i=(center+n+count)%count,p=positions[i];
      const d=(position.x-p.x)**2+(position.z-p.z)**2;
      if(d<bestD){bestD=d;best=i;}
    }
    let fine=best;
    for(let n=-step;n<=step;n++){
      const i=(best+n+count)%count,p=positions[i];
      const d=(position.x-p.x)**2+(position.z-p.z)**2;
      if(d<bestD){bestD=d;fine=i;}
    }
    const i=fine,j=(i+1)%count,p=positions[i],q=positions[j];
    const dx=q.x-p.x,dz=q.z-p.z;
    const a=THREE.MathUtils.clamp(((position.x-p.x)*dx+(position.z-p.z)*dz)/(dx*dx+dz*dz),0,1);
    const t=wrap01((i+a)/count),s=sample(t);
    v.copy(position).sub(s.position);
    return {...s,t,distance:Math.sqrt(bestD),offset:v.dot(s.right)};
  }
  return {curve,length,width:14,sample,nearest,positions,checkpoints:12};
}
