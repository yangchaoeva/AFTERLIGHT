import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

/** Original designs, metres. +Z is the nose; local ground is Y = 0. */
export const CAR_SPECS = Object.freeze([
  { id: 'aurora', name: 'AURORA GT', subtitle: '曙光 · GRAND TOURER', drivetrain: 'AWD', color: '#e8a64b', topSpeed: 286, acceleration: 15.1, handling: 0.94, braking: 27, mass: 1460, wheelbase: 2.72, description: '宽体四驱 GT，平衡、稳定、出弯有力。' },
  { id: 'kasumi', name: 'KASUMI R', subtitle: '雾刃 · CLUB SPORT', drivetrain: 'RWD', color: '#71c8c3', topSpeed: 273, acceleration: 14.5, handling: 1.07, braking: 29, mass: 1230, wheelbase: 2.62, description: '轻量双门跑车，转向灵敏，山路性格。' },
  { id: 'vesper', name: 'VESPER X', subtitle: '暮星 · MID ENGINE', drivetrain: 'RWD', color: '#e9604c', topSpeed: 312, acceleration: 16.7, handling: 0.9, braking: 28, mass: 1380, wheelbase: 2.8, description: '低重心中置超跑，高速强劲，极限更鲜明。' },
]);

const clamp = THREE.MathUtils.clamp;
const V = (x, y, z) => new THREE.Vector3(x, y, z);
const TAU = Math.PI * 2;

// Every static car component is baked into a material batch. Wheels stay articulated.
class Parts {
  constructor() { this.parts = new Map(); }
  add(geometry, material, position = [0, 0, 0], rotation = [0, 0, 0], scale = [1, 1, 1]) {
    const matrix = new THREE.Matrix4().compose(new THREE.Vector3(...position), new THREE.Quaternion().setFromEuler(new THREE.Euler(...rotation)), new THREE.Vector3(...scale));
    geometry.applyMatrix4(matrix);
    if (geometry.index) { const expanded = geometry.toNonIndexed(); geometry.dispose(); geometry = expanded; }
    for (const key of Object.keys(geometry.attributes)) if (!['position', 'normal', 'uv'].includes(key)) geometry.deleteAttribute(key);
    if (!geometry.attributes.normal) geometry.computeVertexNormals();
    if (!geometry.attributes.uv) geometry.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(geometry.attributes.position.count * 2), 2));
    geometry.clearGroups();
    if (!this.parts.has(material)) this.parts.set(material, []);
    this.parts.get(material).push(geometry);
  }
  box(size, material, position, rotation = [0, 0, 0], radius = 0.02) {
    this.add(radius > 0 ? new RoundedBoxGeometry(...size, 2, Math.min(radius, ...size.map(v => v / 2.1))) : new THREE.BoxGeometry(...size), material, position, rotation);
  }
  tube(points, radius, material, steps = 32, closed = false) {
    this.add(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p => V(...p)), closed, 'catmullrom', 0.3), steps, radius, 5, closed), material);
  }
  finish(parent) {
    for (const [material, geometries] of this.parts) {
      const merged = mergeGeometries(geometries, false);
      const mesh = new THREE.Mesh(merged, material);
      mesh.castShadow = !material.userData?.noShadow;
      mesh.receiveShadow = true;
      mesh.name = `batch:${material.name || 'detail'}`;
      parent.add(mesh);
      geometries.forEach(g => g.dispose());
    }
    this.parts.clear();
  }
}

function surface(fn, nu = 24, nv = 10, reverse = false) {
  const positions = [], uvs = [], indices = [];
  for (let j = 0; j <= nv; j++) for (let i = 0; i <= nu; i++) {
    const p = fn(i / nu, j / nv);
    positions.push(...p); uvs.push(i / nu, j / nv);
  }
  for (let j = 0; j < nv; j++) for (let i = 0; i < nu; i++) {
    const a = j * (nu + 1) + i, b = a + 1, c = a + nu + 1, d = c + 1;
    if (reverse) indices.push(a, c, b, b, c, d); else indices.push(a, b, c, b, d, c);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices); geometry.computeVertexNormals();
  return geometry;
}

function smoothProfile(points, z) {
  for (let i = 0; i < points.length - 1; i++) {
    if (z <= points[i + 1][0]) {
      const t = clamp((z - points[i][0]) / (points[i + 1][0] - points[i][0]), 0, 1);
      const s = t * t * (3 - 2 * t);
      return THREE.MathUtils.lerp(points[i][1], points[i + 1][1], s);
    }
  }
  return points[points.length - 1][1];
}

function materials(color, model) {
  function physical(name, options) { const m = new THREE.MeshPhysicalMaterial(options); m.name = name; return m; }
  function standard(name, options) { const m = new THREE.MeshStandardMaterial(options); m.name = name; return m; }
  return {
    paint: physical('pearlescent body paint', { color, metalness: 0.76, roughness: 0.19, clearcoat: 1, clearcoatRoughness: 0.075, envMapIntensity: 1.7, side: THREE.DoubleSide }),
    glass: physical('smoked laminated glass', { color: '#172e3c', metalness: 0.38, roughness: 0.075, transparent: true, opacity: 0.91, clearcoat: 1, clearcoatRoughness: 0.03, envMapIntensity: 1.3, side: THREE.DoubleSide, depthWrite: false }),
    black: standard('satin black trim', { color: '#10151a', roughness: 0.49, metalness: 0.28 }),
    carbon: physical('graphite composite', { color: '#182128', metalness: 0.43, roughness: 0.34, clearcoat: 0.65 }),
    rubber: standard('tire rubber', { color: '#15191c', roughness: 0.92, metalness: 0.02 }),
    tread: standard('tire molded detail', { color: '#252a2c', roughness: 0.91 }),
    rim: standard('forged brushed alloy', { color: model === 'kasumi' ? '#d5c19b' : '#b7c7d1', metalness: 0.88, roughness: 0.26 }),
    brake: standard('machined rotor steel', { color: '#707d83', metalness: 0.82, roughness: 0.43 }),
    caliper: physical('ceramic brake calipers', { color: model === 'vesper' ? '#edbd42' : '#e94b32', metalness: 0.22, roughness: 0.34, clearcoat: 0.8 }),
    chrome: standard('polished metal', { color: '#cbd9e2', metalness: 0.96, roughness: 0.17 }),
    interior: standard('charcoal alcantara', { color: '#212b32', roughness: 0.92 }),
    leather: standard('seat bolsters', { color: '#101c23', roughness: 0.6 }),
    seam: standard('contrast stitching', { color: '#d4b58b', roughness: 0.8 }),
    white: standard('daytime light emitters', { color: '#e8f8ff', emissive: '#d2f2ff', emissiveIntensity: 2.8, roughness: 0.18, metalness: 0.12 }),
    red: standard('rear light emitters', { color: '#fa2633', emissive: '#f31b24', emissiveIntensity: 1.5, roughness: 0.24 }),
    lens: physical('headlamp optical lenses', { color: '#a1cddd', metalness: 0.3, roughness: 0.08, clearcoat: 1 }),
    amber: standard('amber marker lamps', { color: '#ffa95c', emissive: '#fc7825', emissiveIntensity: 0.7 }),
  };
}

function makeWheel(m, side, high) {
  const pivot = new THREE.Group();
  const spin = new THREE.Group(); pivot.add(spin);
  const p = new Parts();
  const radial = high ? 44 : 24;
  // The lathed tire includes a crowned tread, shoulder, recessed sidewall and bead.
  const tireProfile = [
    [.247, -.142], [.302, -.15], [.339, -.134], [.36, -.106], [.369, -.06],
    [.373, 0], [.369, .06], [.36, .106], [.339, .134], [.302, .15], [.247, .142],
    [.242, .112], [.242, -.112], [.247, -.142],
  ];
  p.add(new THREE.LatheGeometry(tireProfile.map(v => new THREE.Vector2(...v)), radial), m.rubber, [0, 0, 0], [0, 0, Math.PI / 2]);
  const face = side * .151;
  const discX = side * .072;
  const axisX = [0, Math.PI / 2, 0];
  p.add(new THREE.TorusGeometry(.243, .014, 8, radial), m.rim, [face, 0, 0], axisX);
  p.add(new THREE.TorusGeometry(.224, .006, 5, radial), m.rim, [face + side * .007, 0, 0], axisX);
  p.add(new THREE.CylinderGeometry(.213, .213, .018, radial), m.brake, [discX, 0, 0], [0, 0, Math.PI / 2]);
  p.add(new THREE.CylinderGeometry(.083, .083, .028, 24), m.rim, [face - side * .045, 0, 0], [0, 0, Math.PI / 2]);
  p.add(new THREE.CylinderGeometry(.049, .049, .012, 20), m.black, [face + side * .006, 0, 0], [0, 0, Math.PI / 2]);
  p.add(new THREE.CylinderGeometry(.02, .02, .015, 12), m.rim, [face + side * .012, 0, 0], [0, 0, Math.PI / 2]);
  const spokeCount = high ? 10 : 5;
  for (let i = 0; i < spokeCount; i++) {
    const a = i * TAU / spokeCount + .13;
    const r = .148;
    // Tangentially swept twin-depth forged spokes.
    p.box([.029, .165, high ? .024 : .04], m.rim, [face - side * .008, Math.cos(a) * r, Math.sin(a) * r], [a + .14, 0, side * -.12], .005);
  }
  if (high) {
    for (const x of [-.142, .142]) {
      p.add(new THREE.TorusGeometry(.314, .0023, 3, radial), m.tread, [x, 0, 0], axisX);
      p.add(new THREE.TorusGeometry(.285, .0018, 3, radial), m.tread, [x, 0, 0], axisX);
    }
    for (let i = 0; i < 32; i++) {
      const a = i * TAU / 32;
      // Thin embossed shoulder sipes; batch geometry costs no extra draw calls.
      p.box([.18, .0019, .009], m.tread, [0, .372 * Math.cos(a), .372 * Math.sin(a)], [a, -.18, 0], 0);
    }
    for (let i = 0; i < 24; i++) {
      const a = i * TAU / 24, r = i % 2 ? .163 : .189;
      p.add(new THREE.CircleGeometry(.007, 5), m.black, [discX + side * .010, Math.cos(a) * r, Math.sin(a) * r], [0, side * Math.PI / 2, 0]);
    }
    for (let i = 0; i < 5; i++) {
      const a = i * TAU / 5;
      p.add(new THREE.CylinderGeometry(.008, .008, .012, 6), m.chrome, [face + side * .005, Math.cos(a) * .063, Math.sin(a) * .063], [0, 0, Math.PI / 2]);
    }
  }
  p.finish(spin);
  const fixed = new Parts();
  fixed.box([.075, .138, .073], m.caliper, [side * .095, .018, -.17], [.15, 0, 0], .022);
  if (high) fixed.box([.077, .087, .02], m.chrome, [side * .096, .02, -.211], [.15, 0, 0], .003);
  fixed.finish(pivot);
  return { pivot, spin };
}

function interior(p, m, cabinShift, high) {
  // Interior is genuinely present behind tinted glass, including twin bucket seats.
  p.box([1.37, .14, 1.66], m.interior, [0, .65, -.28 + cabinShift], [0, 0, 0], .05);
  p.box([1.4, .20, .30], m.leather, [0, .98, .40 + cabinShift], [.09, 0, 0], .045);
  p.box([.2, .21, 1.1], m.black, [0, .78, -.12 + cabinShift], [0, 0, 0], .035);
  for (const side of [-1, 1]) {
    const x = side * .4;
    p.box([.43, .11, .47], m.interior, [x, .77, -.26 + cabinShift], [.08, 0, 0], .045);
    p.box([.38, .48, .12], m.interior, [x, 1.00, -.59 + cabinShift], [-.16, 0, 0], .045);
    p.box([.23, .17, .105], m.leather, [x, 1.28, -.64 + cabinShift], [-.13, 0, 0], .035);
    for (const s of [-1, 1]) {
      p.box([.075, .42, .17], m.leather, [x + s * .18, .96, -.55 + cabinShift], [-.16, 0, s * .09], .032);
      p.box([.068, .095, .4], m.leather, [x + s * .18, .81, -.26 + cabinShift], [.08, 0, 0], .02);
      if (high) p.tube([[x + s * .13, .79, -.12 + cabinShift], [x + s * .13, .80, -.43 + cabinShift], [x + s * .135, 1.16, -.58 + cabinShift]], .003, m.seam, 16);
    }
  }
  p.add(new THREE.TorusGeometry(.135, .017, 7, 24), m.leather, [-.40, 1.03, .24 + cabinShift], [-.4, 0, 0]);
  p.box([.21, .025, .025], m.chrome, [-.4, 1.03, .24 + cabinShift], [-.4, 0, 0], .007);
  p.box([.10, .066, .045], m.black, [-.4, 1.02, .24 + cabinShift], [-.4, 0, 0], .012);
  p.box([.24, .125, .015], m.black, [-.40, 1.07, .435 + cabinShift], [-.18, 0, 0], .012);
  p.box([.22, .12, .015], m.lens, [.02, 1.08, .42 + cabinShift], [-.18, 0, 0], .012);
}

/** Creates a detailed original GT/sports car without external model assets or DOM. */
export function createCar({ model = 'aurora', color, detail = 'high' } = {}) {
  const spec = CAR_SPECS.find(s => s.id === model) || CAR_SPECS[0];
  model = spec.id;
  const high = detail !== 'low';
  const exotic = model === 'vesper', club = model === 'kasumi';
  const m = materials(color ?? spec.color, model);
  const car = new THREE.Group(); car.name = spec.name;
  const body = new THREE.Group(); body.name = 'sprung body'; car.add(body);
  const p = new Parts();
  const frontAxle = spec.wheelbase / 2, rearAxle = -spec.wheelbase / 2;
  const nose = exotic ? 2.37 : club ? 2.18 : 2.32;
  const tail = exotic ? -2.30 : club ? -2.16 : -2.29;
  const halfWidth = exotic ? 1.015 : club ? .93 : .99;
  const cabinShift = exotic ? .25 : club ? -.06 : 0;
  const roofY = exotic ? 1.30 : club ? 1.44 : 1.43;
  const hoodScale = exotic ? .91 : 1;
  const widths = [[tail, .81], [tail + .20, .94], [-1.42, 1], [-.8, .965], [0, .94], [1.35, 1], [nose - .2, .94], [nose, .85]];
  const tops = [[tail, .72], [tail + .28, .82], [-1.15, .94], [0, .94], [.65, .92 * hoodScale], [1.3, .80 * hoodScale], [nose - .35, .70 * hoodScale], [nose, .64]];
  const width = z => smoothProfile(widths, z) * halfWidth;
  const arch = z => {
    const d = Math.min(Math.abs(z - frontAxle), Math.abs(z - rearAxle));
    return d < .43 ? .372 + Math.sqrt(Math.max(0, .43 * .43 - d * d)) : .245;
  };
  const top = (u, z) => {
    const base = smoothProfile(tops, z), edge = Math.abs(u);
    const fender = Math.exp(-Math.pow((z - frontAxle) / .68, 2)) + Math.exp(-Math.pow((z - rearAxle) / .62, 2));
    const shoulder = Math.max(base - .025 + .14 * fender, arch(z) + .052);
    const blend = Math.pow(edge, 3.2);
    return base + .025 * (1 - u * u) + (shoulder - base) * blend;
  };
  const longitudinal = high ? 112 : 60;
  // A continuous crowned upper shell flows into muscular wheel shoulders.
  p.add(surface((u, v) => { const z = tail + (nose - tail) * v, x = u * 2 - 1; return [x * width(z), top(x, z), z]; }, high ? 36 : 18, longitudinal, true), m.paint);
  for (const side of [-1, 1]) {
    // The lower boundary rises around the tire. These are real openings, not black decals.
    p.add(surface((u, v) => {
      const z = tail + (nose - tail) * u, lo = arch(z), hi = top(1, z);
      const y = lo + (hi - lo) * v;
      return [side * (width(z) - .025 * Math.sin(Math.PI * v) - .065 * (1 - v)), y, z];
    }, longitudinal, 10, side > 0), m.paint);
    // Fine arch lip with interior black wheel tub visible above each tire.
    for (const axle of [frontAxle, rearAxle]) {
      const pts = [], innerPts = [];
      for (let i = 0; i <= 36; i++) {
        const a = .05 + (Math.PI - .10) * i / 36;
        const z = axle + Math.cos(a) * .43, y = .372 + Math.sin(a) * .43;
        pts.push([side * (width(z) - .056), y + .001, z]);
        innerPts.push([side * (width(z) - .087), y - .017, z]);
      }
      p.tube(pts, .010, m.paint, high ? 42 : 24);
      p.tube(innerPts, .019, m.black, high ? 38 : 22);
      // A full liner closes the wheel housing behind the moving tire.
      p.add(surface((u,v)=>{
        const a=u*Math.PI;
        return [side*THREE.MathUtils.lerp(halfWidth-.45,halfWidth-.07,v),.372+Math.sin(a)*.445,axle+Math.cos(a)*.445];
      },high?36:20,3,side<0),m.black);
      p.add(new THREE.CircleGeometry(.44,high?40:24,0,Math.PI),m.black,[side*(halfWidth-.44),.372,axle],[0,side*Math.PI/2,0]);
    }
    p.tube([[side * .88 * halfWidth, .25, rearAxle + .52], [side * .95 * halfWidth, .245, -.2], [side * .90 * halfWidth, .25, frontAxle - .52]], .035, m.carbon, 24);
    p.tube([[side * .9 * halfWidth, .284, rearAxle + .54], [side * .96 * halfWidth, .28, -.2], [side * .91 * halfWidth, .28, frontAxle - .56]], .009, m.paint, 24);
  }
  // Sculpted end caps follow the shell, with intake and optical units layered over them.
  for (const [z, front] of [[nose, true], [tail, false]]) {
    p.add(surface((u, v) => {
      const x = (u * 2 - 1) * width(z), lo = front ? .27 : .32;
      return [x, lo + (top(u * 2 - 1, z) - lo) * v, z + (front ? 1 : -1) * .035 * Math.sin(Math.PI * u) * Math.sin(Math.PI * v)];
    }, 28, 8, !front), m.paint);
  }
  // Dark underside does not fill the visible wheel apertures.
  p.box([1.30, .055, nose - tail - .2], m.black, [0, .25, (nose + tail) / 2], [0, 0, 0], .018);

  // Cabin: curved roof, raked windshield, fastback rear glass and sculpted side glazing.
  const roofFront = .09 + cabinShift, roofBack = -.72 + cabinShift;
  const windBase = .67 + cabinShift, rearBase = -1.29 + cabinShift;
  const roofHalf = exotic ? .625 : club ? .65 : .66;
  p.add(surface((u, v) => {
    const t = u * 2 - 1, z = roofBack + (roofFront - roofBack) * v;
    return [t * roofHalf * (1 - .035 * Math.cos(v * TAU)), roofY + .052 * (1 - t * t) + .018 * Math.sin(v * Math.PI), z];
  }, 28, 18, true), exotic ? m.carbon : m.paint);
  const windFn = (u, v) => {
    const t = u * 2 - 1, half = THREE.MathUtils.lerp(.755, roofHalf, v);
    return [t * half, THREE.MathUtils.lerp(.97, roofY, v) + .027 * (1 - t * t), THREE.MathUtils.lerp(windBase, roofFront, v) + .04 * (1 - t * t) * Math.sin(Math.PI * v)];
  };
  const rearFn = (u, v) => {
    const t = u * 2 - 1, half = THREE.MathUtils.lerp(.77, roofHalf, v);
    return [t * half, THREE.MathUtils.lerp(.97, roofY, v) + .025 * (1 - t * t), THREE.MathUtils.lerp(rearBase, roofBack, v) - .025 * (1 - t * t)];
  };
  p.add(surface(windFn, 26, 16), m.glass);
  p.add(surface(rearFn, 26, 16, true), m.glass);
  for (const fn of [windFn, rearFn]) {
    for (const edge of [0, 1]) {
      const pts = [];
      for (let i = 0; i <= 18; i++) pts.push(fn(i / 18, edge));
      p.tube(pts, edge ? .017 : .022, m.black, 25);
    }
  }
  for (const side of [-1, 1]) {
    const pts = [
      [side * .755, .97, windBase], [side * roofHalf, roofY, roofFront],
      [side * roofHalf, roofY, roofBack], [side * .77, .97, rearBase],
    ];
    // Side windows form a four-sided ruled surface; subtle convexity catches sky light.
    p.add(surface((u, v) => {
      const bottomZ = THREE.MathUtils.lerp(rearBase + .02, windBase - .015, u);
      const topZ = THREE.MathUtils.lerp(roofBack, roofFront, u);
      return [side * (THREE.MathUtils.lerp(.765, roofHalf, v) + .012 * Math.sin(Math.PI * u) * Math.sin(Math.PI * v)), THREE.MathUtils.lerp(.975, roofY, v) + .008 * Math.sin(Math.PI * u), THREE.MathUtils.lerp(bottomZ, topZ, v)];
    }, 20, 10, side > 0), m.glass);
    p.tube([pts[0], [side * .715, 1.10, windBase - .18], pts[1]], .035, m.paint, 24);
    p.tube([pts[1], [side * roofHalf, roofY + .01, (roofFront + roofBack) / 2], pts[2]], .027, m.paint, 28);
    p.tube([pts[2], [side * .714, 1.14, rearBase + .18], pts[3]], exotic ? .07 : .061, m.paint, 24);
    p.tube([[side * .77, .97, rearBase], [side * .80, .959, -.2 + cabinShift], [side * .755, .97, windBase]], .02, m.black, 36);
    p.tube([[side * .71, roofY - .025, -.56 + cabinShift], [side * .78, .979, -.79 + cabinShift]], .018, m.black, 14);
    // Door outlines sit on the lower side, terminating clear of the wheel arches.
    const doorRear = -.77 + cabinShift, doorFront = .72 + cabinShift;
    const doorPts = [
      [side * (width(doorRear) + .002), top(1, doorRear) - .02, doorRear],
      [side * (width(doorRear) - .027), .61, doorRear + .02],
      [side * (width(doorRear + .15) - .052), .35, doorRear + .15],
      [side * (width(.1) - .055), .325, .1],
      [side * (width(doorFront - .13) - .05), .38, doorFront - .13],
      [side * (width(doorFront) - .018), .68, doorFront],
      [side * (width(doorFront) + .001), top(1, doorFront) - .015, doorFront],
    ];
    p.tube(doorPts, high ? .0035 : .004, m.black, 48);
    p.box([.014, .025, .15], m.black, [side * (width(doorRear + .18) - .003), .845, doorRear + .18], [0, 0, 0], .01);
    p.box([.016, .009, .105], m.chrome, [side * width(doorRear + .18), .85, doorRear + .18], [0, 0, 0], .004);
    // Mirrors on a real stalk with painted fairing and optical face.
    p.tube([[side * .77, .99, .45 + cabinShift], [side * .91, 1.01, .49 + cabinShift], [side * 1.02, 1.025, .49 + cabinShift]], .018, m.black, 12);
    p.add(new THREE.SphereGeometry(1, 18, 10), m.paint, [side * 1.035, 1.045, .49 + cabinShift], [0, side * -.12, 0], [.137, .060, .082]);
    p.box([.174, .062, .012], m.chrome, [side * 1.037, 1.049, .424 + cabinShift], [0, side * -.12, 0], .02);
    p.tube([[side * .97, 1.043, .55 + cabinShift], [side * 1.06, 1.043, .561 + cabinShift]], .004, m.white, 10);
  }
  interior(p, m, cabinShift, high);

  // Hood shut lines, subtle power bulges and tucked windshield wipers.
  for (const side of [-1, 1]) {
    const hoodPoints = [];
    for (let i = 0; i <= 20; i++) {
      const z = windBase + .04 + (nose - .22 - windBase) * i / 20;
      const x = side * (.53 + .06 * Math.sin(Math.PI * i / 20));
      hoodPoints.push([x, top(x / width(z), z) + .004, z]);
    }
    p.tube(hoodPoints, .003, m.black, 34);
    if (high) {
      const crease = hoodPoints.map(v => [v[0] * .79, v[1] + .006, v[2]]);
      p.tube(crease, .007, m.paint, 34);
    }
    p.tube([[side * .15, .987, windBase + .015], [side * .43, 1.005, windBase - .015], [side * .66, 1.015, windBase - .043]], .009, m.black, 14);
  }

  // Front lower intake and side channels are inset black volumes with real grille vanes.
  p.box([1.10, .195, .10], m.black, [0, .408, nose + .026], [0, 0, 0], .057);
  p.box([1.24, .030, .18], m.carbon, [0, .284, nose + .046], [0, 0, 0], .012);
  for (const side of [-1, 1]) {
    p.box([.25, .18, .12], m.black, [side * .68, .395, nose - .039], [0, side * .14, 0], .034);
    p.box([.028, .16, .19], m.paint, [side * .506, .407, nose + .027], [0, side * -.18, 0], .01);
    for (let i = 0; i < (high ? 3 : 2); i++) p.box([.194, .012, .055], m.carbon, [side * .68, .345 + i * .045, nose + .023], [0, side * .14, 0], .003);
    const lampZ = nose - .145;
    p.box([.46, .105, .145], m.black, [side * .58, .668, lampZ], [-.16, side * -.19, side * -.045], .038);
    p.box([.425, .073, .143], m.lens, [side * .58, .673, lampZ + .009], [-.16, side * -.19, side * -.045], .029);
    // Thin double optical blades give the car a distinct light signature.
    for (const y of [.655, .688]) p.tube([[side * .386, y, lampZ + .077], [side * .59, y + .011, lampZ + .087], [side * .776, y + .010, lampZ + .058]], exotic ? .008 : .010, m.white, 22);
    if (high) for (let i = 0; i < 3; i++) p.add(new THREE.SphereGeometry(.02, 10, 6), m.white, [side * (.47 + i * .095), .672, lampZ + .080], [0, 0, 0], [1, .7, .3]);
    p.box([.015, .045, .075], m.amber, [side * (width(nose - .45) + .008), .62, nose - .45], [0, 0, 0], .008);
  }
  if (high) for (let i = -7; i <= 7; i++) p.box([.013, .143, .018], m.carbon, [i * .064, .408, nose + .084], [0, 0, .15], .003);

  // Rear horizontal light sculpture, diffuser and twin metal exhaust outlets.
  p.box([1.54, .13, .095], m.black, [0, .705, tail - .025], [0, 0, 0], .04);
  for (const side of [-1, 1]) {
    p.tube([[side * .07, .745, tail - .079], [side * .52, .741, tail - .083], [side * .748, .715, tail - .064]], .012, m.red, 25);
    p.tube([[side * .20, .693, tail - .081], [side * .55, .690, tail - .083], [side * .75, .704, tail - .064]], .008, m.red, 22);
    p.box([.33, .14, .078], m.black, [side * .58, .473, tail - .026], [0, 0, 0], .025);
    for (let i = 0; i < (high ? 4 : 2); i++) p.box([.29, .008, .01], m.carbon, [side * .58, .428 + i * .028, tail - .074], [0, 0, 0], .002);
    const exhaustY = exotic ? .49 : .345;
    const exhaustX = exotic ? .31 : .59;
    p.add(new THREE.CylinderGeometry(.068, .063, .13, high ? 24 : 14, 1, true), m.chrome, [side * exhaustX, exhaustY, tail - .057], [Math.PI / 2, 0, 0]);
    p.add(new THREE.CircleGeometry(.057, 20), m.black, [side * exhaustX, exhaustY, tail - .127], [0, Math.PI, 0]);
  }
  p.box([1.63, .11, .31], m.carbon, [0, .265, tail + .021], [-.08, 0, 0], .033);
  for (let i = -3; i <= 3; i++) p.box([.014, .11, .35], m.carbon, [i * .2, .261, tail + .034], [-.12, 0, 0], .004);
  p.box([.34, .11, .021], m.black, [0, .494, tail - .047], [0, 0, 0], .01);
  p.box([.29, .08, .022], m.chrome, [0, .494, tail - .060], [0, 0, 0], .008);
  // Original split-chevron emblem (geometry, never a copied manufacturer badge).
  for (const side of [-1, 1]) {
    p.box([.013, .052, .006], m.chrome, [side * .014, .718, tail - .093], [0, 0, side * -.43], .002);
    p.box([.009, .035, .035], m.chrome, [side * .012, top(0, nose - .26) + .008, nose - .26], [.63, 0, side * -.35], .002);
  }
  // Aerodynamics and additional design language differentiate the three originals.
  if (exotic) {
    for (const side of [-1, 1]) {
      p.box([.028, .25, .50], m.black, [side * .96, .66, -.66], [0, side * .08, side * -.06], .06);
      p.tube([[side * .948, .52, -.40], [side * .988, .73, -.76], [side * .967, .85, -.95]], .025, m.paint, 26);
      for (let i = 0; i < 3; i++) p.box([.032, .012, .29], m.carbon, [side * .98, .59 + i * .062, -.64], [0, side * .06, 0], .003);
      // Ventilated rear engine deck.
      for (let i = 0; i < 6; i++) p.box([.29, .012, .035], m.black, [side * .32, .905 - i * .012, -1.35 - i * .074], [0, 0, 0], .005);
    }
  } else {
    for (const side of [-1, 1]) {
      const ventZ = frontAxle - .58;
      p.box([.02, .112, .235], m.black, [side * (width(ventZ) - .002), .701, ventZ], [0, 0, 0], .025);
      for (let i = 0; i < 3; i++) p.box([.029, .009, .181], m.chrome, [side * width(ventZ), .669 + i * .032, ventZ], [0, 0, 0], .003);
    }
  }
  const wing = new THREE.Group(); wing.name = 'active rear aero'; body.add(wing);
  const aero = new Parts();
  if (club || exotic) {
    const wingY = club ? 1.02 : .99, wingZ = tail + .30;
    for (const side of [-1, 1]) aero.box([.031, .18, .13], m.carbon, [side * .56, wingY - .11, wingZ], [-.13, 0, 0], .01);
    aero.add(surface((u, v) => [(u * 2 - 1) * (club ? .96 : .90), wingY + .038 * Math.sin(v * Math.PI) - .026 * v, wingZ - .14 + v * .29], 24, 10, true), m.carbon);
    for (const side of [-1, 1]) aero.box([.025, .092, .34], m.carbon, [side * (club ? .96 : .90), wingY + .012, wingZ], [0, 0, 0], .018);
  } else {
    const wingPoints = [];
    for (let i = 0; i <= 24; i++) { const x = (i / 24 * 2 - 1) * .84, z = tail + .13 + .065 * Math.pow(x / .84, 2); wingPoints.push([x, top(x / width(z), z) + .025, z]); }
    aero.tube(wingPoints, .021, m.carbon, 38);
  }
  aero.finish(wing);
  p.finish(body);

  const wheels = [];
  for (const front of [true, false]) for (const side of [-1, 1]) {
    const wheel = makeWheel(m, side, high);
    wheel.pivot.position.set(side * (halfWidth - .12), .373, front ? frontAxle : rearAxle);
    wheel.pivot.name = `${front ? 'front' : 'rear'} ${side < 0 ? 'left' : 'right'} wheel`;
    car.add(wheel.pivot); wheels.push({ ...wheel, front, side });
  }
  car.userData = { spec, model, wheels, body, paint: m.paint, brakeLights: [m.red], headLights: [m.white], materials: m, wing, wheelRadius: .373, halfWidth, length: nose - tail, speed: 0, detail };
  return car;
}

/** Kinematic detail animation. Speed is metres per second; steer is -1..1. */
export function updateCar(car, { steer = 0, speed = 0, brake = 0, time = 0, dt = 1 / 60 } = {}) {
  const data = car.userData;
  dt = clamp(dt, 0, .08);
  for (const wheel of data.wheels) {
    wheel.pivot.rotation.y = wheel.front ? steer * .44 : 0;
    wheel.spin.rotation.x += speed * dt / data.wheelRadius;
  }
  const acceleration = (speed - data.speed) / Math.max(dt, .001);
  data.speed = speed;
  const ease = 1 - Math.exp(-dt * 8);
  const pitch = clamp(-acceleration * .0018, -.035, .042);
  const roll = clamp(steer * Math.abs(speed) * .0016, -.05, .05);
  data.body.rotation.x += (pitch - data.body.rotation.x) * ease;
  data.body.rotation.z += (roll - data.body.rotation.z) * ease;
  data.body.position.y = Math.sin(time * 11) * Math.min(Math.abs(speed) * .00010, .003);
  for (const material of data.brakeLights) material.emissiveIntensity = brake > .05 ? 5.0 : 1.45;
}
