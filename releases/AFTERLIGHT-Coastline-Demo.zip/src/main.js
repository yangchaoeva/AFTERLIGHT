import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { RGBELoader } from 'three/addons/loaders/RGBELoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import '@fontsource/barlow-condensed/500.css';
import '@fontsource/barlow-condensed/600.css';
import '@fontsource/manrope/400.css';
import '@fontsource/manrope/600.css';
import '@fontsource/manrope/800.css';
import './style.css';
import { mountUI,timeString } from './ui.js';
import { createTrack,wrap01 } from './track.js';
import { createCar,updateCar } from './vehicle.js';
import { createWorld } from './world.js';
import { RaceAudio } from './audio.js';
import { VEHICLES,createDriver,resetDriver,stepDriver,aiControls,resolveCars,updateRaceProgress,ranking,steeringLimit } from './physics.js';

const $=mountUI();
const settings=readSave('afterlight.settings',{quality:'medium',sound:true,voice:true,dynamicCamera:true,fps:false});
let state='loading',selectedModel='aurora',paint='#b8d9cf',mode='race',difficulty='normal';
let renderer,scene,camera,world,track,controls,heroCar,drivers=[],carMeshes=[],player;
let coastEnvironment,studioEnvironment,studioFloor,studioLighting,coastBackground;
let elapsed=0,raceTime=0,accumulator=0,countdownTime=0,countdownNumber=-1,totalLaps=2;
let cameraMode=0,menuTime=0,lastHud=0,lastPosition=8,lastOvertake=-20,toastUntil=0;
let eventUntil=0,lastFrame=performance.now(),fpsElapsed=0,fpsFrames=0,frameCount=0;
let resumeState='racing',studioView='orbit',studioTransition=0,heldButtons=new Set();
const keys=new Set(),touch={left:false,right:false,throttle:false,brake:false};
const audio=new RaceAudio();
const up=new THREE.Vector3(0,1,0),camPos=new THREE.Vector3(),camTarget=new THREE.Vector3();
const aimTarget=new THREE.Vector3(),lastPlayerPosition=new THREE.Vector3();
const carColors=['#d9d6cc','#d46d4e','#536f84','#dfb64c','#97b09a','#9380a9','#454d54'];

function readSave(key,fallback){try{return {...fallback,...JSON.parse(localStorage.getItem(key)||'{}')};}catch{return fallback;}}
function writeSave(key,data){try{localStorage.setItem(key,JSON.stringify(data));}catch{/* storage is optional */}}
function show(id,visible=true){$(id).hidden=!visible;}
function toast(text,duration=3){$('toast').textContent=text;show('toast');toastUntil=elapsed+duration;}
function banner(title,subtitle,duration=3){$('event-banner').innerHTML=`<strong>${title}</strong><small>${subtitle}</small>`;show('event-banner');eventUntil=elapsed+duration;}
function disposeCar(car){if(!car)return;const materials=new Set();car.traverse(o=>{o.geometry?.dispose();if(o.material)for(const m of [].concat(o.material))materials.add(m);});materials.forEach(m=>m.dispose());car.removeFromParent();}

function setQuality(){
 const quality=settings.quality;
 renderer.setPixelRatio(Math.min(devicePixelRatio,quality==='high'?1.75:quality==='medium'?1.25:1));
 renderer.shadowMap.enabled=quality!=='low';
 renderer.setSize(innerWidth,innerHeight);
 if(world?.sunLight){world.sunLight.shadow.mapSize.set(quality==='high'?2048:1024,quality==='high'?2048:1024);world.sunLight.shadow.map?.dispose();world.sunLight.shadow.map=null;}
}
function syncSettings(){
 $('quality').value=settings.quality;$('sound-enabled').checked=settings.sound;
 $('voice-enabled').checked=settings.voice;$('dynamic-camera').checked=settings.dynamicCamera;
 $('show-fps').checked=settings.fps;show('fps',settings.fps);
 audio.setMuted(!settings.sound);audio.setVoiceEnabled(settings.voice);
 if(renderer)setQuality();
}

function positionHero(){
 const s=track.sample(.825);
 heroCar.position.copy(s.position).addScaledVector(s.right,-.2);
 heroCar.rotation.set(0,s.heading+.07,0);
}
function selectCar(model){
 selectedModel=model;disposeCar(heroCar);
 heroCar=createCar({model,color:paint,detail:'high'});heroCar.name='hero-car';scene.add(heroCar);positionHero();
 document.querySelectorAll('[data-model]').forEach(e=>e.classList.toggle('selected',e.dataset.model===model));
 const spec=VEHICLES[model];
 $('hero-car-name').textContent=spec.label;
 $('hero-car-sub').textContent=`${spec.power} HP / ${spec.layout}`;
 $('studio-name').textContent=spec.label;$('studio-power').textContent=`${spec.power} HP`;
 $('studio-mass').textContent=`${spec.mass} KG`;$('studio-speed').textContent=`${Math.round(spec.topSpeed*3.6)} KM/H`;
 $('studio-layout').textContent=spec.layout.split(' · ')[0];
 $('studio-desc').textContent={aurora:'宽体曲面与四驱底气。为海岸公路而生的原创 GT。',kasumi:'短车身、轻量车架与灵巧后驱。在连续弯道寻找自己的节奏。',vesper:'低矮的中置轮廓与独立尾翼。让风成为车身的一部分。'}[model];
 let triangles=0;heroCar.traverse(o=>{if(o.isMesh)triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3;});
 $('mesh-stat').textContent=`${Math.round(triangles).toLocaleString()} TRIANGLES · 可导出 GLB`;
 if(state==='studio')setStudioView(studioView,true);
}

function setPaint(color){paint=color;if(heroCar)heroCar.userData.paint.color.set(color);document.querySelectorAll('[data-paint]').forEach(e=>e.classList.toggle('selected',e.dataset.paint===color));}

function openStudio(){
 state='studio';show('menu',false);show('studio');heroCar.visible=true;controls.enabled=true;
 controls.minDistance=2;controls.maxDistance=16;controls.maxPolarAngle=Math.PI*.49;
 controls.minPolarAngle=.18;controls.enablePan=false;setStudioView('orbit',true);
 scene.environment=studioEnvironment;scene.environmentIntensity=1;
 scene.background=new THREE.Color('#122229');scene.fog=null;
 for(const child of scene.children)if(child!==heroCar&&child!==studioFloor&&child!==studioLighting)child.visible=false;
 studioFloor.visible=true;studioLighting.visible=true;
 heroCar.position.set(0,0,0);heroCar.rotation.set(0,0,0);setStudioView('orbit',true);
 audio.start().then(()=>audio.say('welcome'));
}
function setStudioView(view,snap=false){
 studioView=view;document.querySelectorAll('[data-view]').forEach(e=>e.classList.toggle('active',e.dataset.view===view));
 const p=heroCar.position,rotation=heroCar.quaternion;
 const local={orbit:[5.8,2.4,6.7],front:[3.1,1.4,4.5],wheel:[2.25,.64,2.10],rear:[-4.1,1.5,-5.0]}[view];
 const targetOffset=view==='wheel'?new THREE.Vector3(1,.47,1.25):new THREE.Vector3(0,.65,view==='rear'?-.7:.1);
 camPos.set(...local).applyQuaternion(rotation).add(p);
 camTarget.copy(targetOffset).applyQuaternion(rotation).add(p);
 if(snap){camera.position.copy(camPos);controls.target.copy(camTarget);controls.update();}
 else studioTransition=1;
}

function returnMenu(){
 state='menu';hideModals();show('hud',false);show('studio',false);show('menu');
 controls.enabled=false;carMeshes.forEach(disposeCar);carMeshes=[];drivers=[];player=null;
 for(const child of scene.children)child.visible=true;
 if(coastBackground)world.skyMesh.visible=false;
 studioFloor.visible=false;studioLighting.visible=false;
 scene.environment=coastEnvironment;scene.environmentIntensity=.8;scene.background=coastBackground;
 scene.fog=new THREE.FogExp2('#b6c4cb',.00023);
 heroCar.visible=true;positionHero();keys.clear();audio.pause();camera.fov=43;camera.updateProjectionMatrix();menuCamera(1,true);
}
function hideModals(){['race-modal','settings-modal','pause-modal','result-modal'].forEach(id=>show(id,false));}

function drawMap(canvas,vehicles=[]){
 const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height,pad=20;
 ctx.clearRect(0,0,w,h);
 const points=track.positions,extent=1050,scale=Math.min(w-2*pad,h-2*pad)/extent;
 const project=p=>[w/2+p.x*scale,h/2+p.z*scale];
 ctx.lineCap='round';ctx.lineJoin='round';
 function route(width,color){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();for(let i=0;i<points.length;i+=7){const [x,y]=project(points[i]);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.closePath();ctx.stroke();}
 route(canvas.id==='minimap'?13:8,'#0c263399');route(canvas.id==='minimap'?4:3,'#cfdbcfb0');
 const [sx,sy]=project(track.sample(0).position);ctx.fillStyle='#e4b76c';ctx.fillRect(sx-4,sy-4,8,8);
 for(const d of [...vehicles].sort((a,b)=>Number(a.isPlayer)-Number(b.isPlayer))){
   const [x,y]=project(d.position);ctx.fillStyle=d.isPlayer?'#efc37b':'#f1f1de';ctx.beginPath();ctx.arc(x,y,d.isPlayer?7:3.5,0,Math.PI*2);ctx.fill();
   if(d.isPlayer){ctx.save();ctx.translate(x,y);ctx.rotate(-d.heading+Math.PI);ctx.beginPath();ctx.moveTo(0,-15);ctx.lineTo(-5,-7);ctx.lineTo(5,-7);ctx.closePath();ctx.fill();ctx.restore();}
 }
}

function setupRace(){
 mode=$('mode').value;difficulty=$('difficulty').value;totalLaps=mode==='time'?1:2;
 hideModals();show('menu',false);show('studio',false);show('hud');controls.enabled=false;heroCar.visible=false;
 carMeshes.forEach(disposeCar);carMeshes=[];drivers=[];
 const names=['MIRA','ELIO','KAI','NOVA','REN','SORA','LUKA'];
 if(mode==='race')for(let i=0;i<7;i++){
   const t=-(6+Math.floor(i/2)*7)/track.length;
   const d=createDriver(track,{id:`ai${i}`,name:names[i],model:['vesper','aurora','kasumi'][i%3],t,lane:i%2===0?-2.7:2.7});
   d.preferredLane=(i%3-1)*2.5;drivers.push(d);
 }
 player=createDriver(track,{id:'player',name:'你',model:selectedModel,t:mode==='race'?-28/track.length:-5/track.length,lane:mode==='race'?2.7:0,isPlayer:true});
 drivers.push(player);
 drivers.forEach((d,i)=>{const car=createCar({model:d.model,color:d.isPlayer?paint:carColors[i%7],detail:d.isPlayer?'high':'low'});scene.add(car);carMeshes.push(car);});
 raceTime=0;accumulator=0;countdownTime=0;countdownNumber=-1;lastPosition=drivers.length;lastOvertake=-20;
 cameraMode=0;camera.fov=57;camera.updateProjectionMatrix();keys.clear();state='countdown';
 $('hud-car').textContent=VEHICLES[selectedModel].label;$('competitors').textContent=`/ ${drivers.length}`;
 $('lap-label').textContent=mode==='time'?'TIME ATTACK / 计时':'LAP / 圈数';
 show('leaderboard',mode==='race');show('countdown');show('event-banner',false);
 updateMeshes(0);raceCamera(1,true);updateHUD();
 audio.start().then(()=>{audio.say('ready');toast('引擎就绪，准备起跑。',2);});
}

function inputState(){
 let throttle=keys.has('KeyW')||keys.has('ArrowUp')||touch.throttle?1:0;
 let brake=keys.has('KeyS')||keys.has('ArrowDown')||touch.brake?1:0;
 let steer=Number(keys.has('KeyD')||keys.has('ArrowRight')||touch.right)-Number(keys.has('KeyA')||keys.has('ArrowLeft')||touch.left);
 let handbrake=keys.has('Space'),digital=true;
 const pad=navigator.getGamepads?.()?.find(p=>p?.connected);
 if(pad){
   const axis=Math.abs(pad.axes[0])>.12?pad.axes[0]:0;
   if(axis){steer=axis;digital=false;}
   throttle=Math.max(throttle,pad.buttons[7]?.value||0);brake=Math.max(brake,pad.buttons[6]?.value||0);handbrake||=pad.buttons[0]?.pressed;
   for(const [index,action] of [[9,'pause'],[3,'camera'],[2,'reset']]){
     if(pad.buttons[index]?.pressed&&!heldButtons.has(index)){heldButtons.add(index);if(action==='pause')togglePause();if(action==='camera')cycleCamera();if(action==='reset')resetPlayer();}
     if(!pad.buttons[index]?.pressed)heldButtons.delete(index);
   }
 }
 return {throttle,brake,steer,handbrake,digital};
}

function resetPlayer(){
 if(state!=='racing'||!player)return;
 const checkpointT=Math.max(0,(player.checkpoint-1)/track.checkpoints);
 const safeT=Math.max(checkpointT,player.startT+player.progress-4/track.length);
 resetDriver(player,track,safeT,0);player.progress=safeT-player.startT;player.penalty+=3;player.respawns++;
 toast('已返回赛道 · 罚时 +3 秒');audio.say('reset');raceCamera(1,true);
}

function cycleCamera(){cameraMode=(cameraMode+1)%3;toast(['追尾镜头','引擎盖镜头','远景追尾'][cameraMode],1.5);if(player)raceCamera(1,true);}
function togglePause(){
 if(state==='racing'||state==='countdown'){
   resumeState=state;state='paused';show('pause-modal');audio.pause();keys.clear();
 } else if(state==='paused'){
   hideModals();state=resumeState;audio.resume();lastFrame=performance.now();keys.clear();
 }
}

function finishRace(){
 state=drivers.every(d=>d.finishTime!==null)?'finished':'finishing';show('countdown',false);audio.say('finish');
 renderResults();
 const records=readSave('afterlight.records',{}),key=`${mode}.${difficulty}.${selectedModel}`;
 const previous=records[key];const isBest=!previous||player.finishTime<previous;
 if(isBest){records[key]=player.finishTime;writeSave('afterlight.records',records);}
 $('record-note').textContent=`${isBest?'刷新本地纪录':'本地最佳 '+timeString(previous)} · ${VEHICLES[selectedModel].name} · ${player.penalty?`复位罚时 ${player.penalty} 秒已计入总成绩`:'无复位罚时'}。`;
 show('result-modal');
}
function renderResults(){
 const results=ranking(drivers),rank=results.indexOf(player)+1,bestLap=Math.min(...player.lapTimes);
 const final=drivers.every(d=>d.finishTime!==null);
 $('result-title').textContent=mode==='time'?'TIME. WELL SPENT.':!final?'ACROSS THE LINE.':rank===1?'THE COAST IS YOURS.':'CHASE COMPLETE.';
 $('result-sub').textContent=!final?'你已冲线。其他车手仍在比赛，最终名次将包含复位罚时。':rank===1&&mode==='race'?'冠军。你追上了海岸的最后一道光。':'冲线。每一个弯，都有再快一点的可能。';
 $('result-position').textContent=mode==='time'?'TIME ATTACK':`${final?'':'暂列 '}${String(rank).padStart(2,'0')} / 08`;
 $('result-time').textContent=timeString(player.finishTime);$('result-lap').textContent=timeString(bestLap);
 $('result-list').innerHTML=results.map((d,i)=>`<div class="result-row ${d.isPlayer?'player':''}"><span>${String(i+1).padStart(2,'0')}</span><span>${d.name} · ${VEHICLES[d.model].label}</span><span>${d.finishTime!==null?timeString(d.finishTime):'未完赛 · '+Math.min(99,Math.floor((d.startT+d.progress)/totalLaps*100))+'%'}</span></div>`).join('');
}

function simulate(dt){
 if(state==='countdown'){
   countdownTime+=dt;
   const number=countdownTime<1?4:countdownTime<2?3:countdownTime<3?2:countdownTime<4?1:0;
   if(number!==countdownNumber){countdownNumber=number;$('countdown').innerHTML=number===4?'<div><small>THE GOLDEN COAST</small><span style="font-size:64px">READY</span></div>':number===0?'<div>GO<small>去追逐你的光</small></div>':`<div>${number}</div>`;if(number<4)audio.say(['go','one','two','three'][number]);}
   if(countdownTime>=4.55){state='racing';show('countdown',false);}
   return;
 }
 if(state!=='racing'&&state!=='finishing')return;
 const input=state==='racing'?inputState():{};if(state!=='racing'&&state!=='finishing')return;
 raceTime+=dt;
 for(const d of drivers){
   const controls=d.isPlayer&&state==='racing'?input:aiControls(d,track,drivers,difficulty);
   stepDriver(d,controls,track,dt);
   if(!d.isPlayer&&d.stuckTime>6){const t=Math.max((d.checkpoint-1)/track.checkpoints,d.startT+d.progress-5/track.length);resetDriver(d,track,t,0);d.progress=t-d.startT;d.penalty+=3;}
 }
 resolveCars(drivers,track,dt);
 for(const d of drivers){
   const event=updateRaceProgress(d,track,raceTime,totalLaps);
   if(d.isPlayer&&event==='lap'){banner('FINAL LAP','最后一圈 · 保持节奏',3);audio.say('finalLap');}
   if(d.isPlayer&&event==='finish'){finishRace();break;}
 }
 if(state==='finishing'&&drivers.every(d=>d.finishTime!==null)){state='finished';renderResults();}
}

function updateMeshes(dt){
 for(let i=0;i<drivers.length;i++){
   const d=drivers[i],car=carMeshes[i],s=track.sample(d.t);
   car.position.copy(d.position);car.rotation.set(-Math.asin(s.tangent.y),d.heading,0,'YXZ');
   updateCar(car,{steer:d.steer*steeringLimit(d.speed)/.44,speed:d.speed,brake:d.brake,time:elapsed,dt});
   car.userData.body.rotation.z=d.roll;car.userData.body.rotation.x=-d.pitch;
   car.visible=true;
 }
}

function menuCamera(dt,snap=false){
 const p=heroCar.position;
 const angle=.85+Math.sin(menuTime*.055)*.07;
 const offset=new THREE.Vector3(-Math.sin(angle)*9.4,2.4,Math.cos(angle)*9.4).applyQuaternion(heroCar.quaternion);
 camPos.copy(p).add(offset);
 const right=new THREE.Vector3(1,0,0).applyQuaternion(heroCar.quaternion);
 camTarget.copy(p).add(new THREE.Vector3(0,.7,0)).addScaledVector(right,-1.75);
 // View offset makes deliberate space for the title without altering car geometry.
 if(snap)camera.position.copy(camPos);else camera.position.lerp(camPos,1-Math.exp(-2*dt));
 camera.lookAt(camTarget);
}

function raceCamera(dt,snap=false){
 if(!player)return;
 const p=player.position,dir=new THREE.Vector3(Math.sin(player.heading),0,Math.cos(player.heading));
 const ground=track.sample(player.t);
 if(cameraMode===1){camPos.copy(p).addScaledVector(dir,1.45);camPos.y+=1.03;camTarget.copy(p).addScaledVector(dir,30);camTarget.y+=1.0+ground.tangent.y*30;}
 else {
   const distance=cameraMode===2?11:7.4,height=cameraMode===2?4.7:3.0;
   camPos.copy(p).addScaledVector(dir,-distance);camPos.y+=height-ground.tangent.y*distance;
   camTarget.copy(p).addScaledVector(dir,10+player.speed*.08);camTarget.y+=1.1+ground.tangent.y*12;
 }
 if(snap){camera.position.copy(camPos);aimTarget.copy(camTarget);}else{camera.position.lerp(camPos,1-Math.exp(-(cameraMode===1?24:8)*dt));aimTarget.lerp(camTarget,1-Math.exp(-10*dt));}
 camera.lookAt(aimTarget);
 const targetFov=cameraMode===1?68:57+(settings.dynamicCamera?Math.min(9,player.speed*.12):0);
 camera.fov=THREE.MathUtils.lerp(camera.fov,targetFov,1-Math.exp(-3*dt));camera.updateProjectionMatrix();
}

function updateShadow(){
 if(!world.sunLight)return;
 const focus=player&&(state!=='menu'&&state!=='studio')?player.position:heroCar.position;
 world.sunLight.target.position.copy(focus);world.sunLight.position.copy(focus).addScaledVector(world.sunDirection,180);
 const shadow=world.sunLight.shadow.camera;
 shadow.left=-55;shadow.right=55;shadow.top=55;shadow.bottom=-55;shadow.near=.5;shadow.far=400;shadow.updateProjectionMatrix();
 world.sunLight.target.updateMatrixWorld();
}

function updateHUD(){
 if(!player)return;
 const ordered=ranking(drivers),rank=ordered.indexOf(player)+1;
 $('position').textContent=rank;$('speed').textContent=String(Math.round(player.speed*3.6)).padStart(3,'0');
 $('gear').textContent=player.speed<1?'N':Math.min(7,1+Math.floor(player.speed/13));
 $('lap').textContent=`${Math.min(totalLaps,player.lap+1)} / ${totalLaps}`;$('timer').textContent=timeString(raceTime+player.penalty);
 $('rpm').style.width=`${18+((player.speed%13)/13)*80}%`;
 const progress=THREE.MathUtils.clamp((player.startT+player.progress)/totalLaps,0,1);
 $('race-progress').style.width=`${progress*100}%`;$('distance-left').textContent=`${((1-progress)*totalLaps*track.length/1000).toFixed(2)} KM`;
 $('drive-assist').textContent=player.slip>.24?'SLIP · 控制油门':'TCS · ABS';
 $('leaderboard').innerHTML=ordered.slice(0,4).map((d,i)=>`<div class="leader-row ${d.isPlayer?'player':''}"><b>${i+1}</b><span>${d.name}</span><span>${d.isPlayer?'YOU':d.finishTime!==null?'FIN':`${Math.max(0,((ordered[0].startT+ordered[0].progress)-(d.startT+d.progress))*track.length/Math.max(d.speed,20)).toFixed(1)}s`}</span></div>`).join('');
 drawMap($('minimap'),drivers);
 if(rank<lastPosition&&raceTime-lastOvertake>12&&raceTime>8&&state==='racing'){toast('漂亮的超车。保持节奏。',2);audio.say('overtake');lastOvertake=raceTime;}
 lastPosition=rank;
}

async function exportModel(){
 const button=$('export-model');button.disabled=true;button.textContent='导出中…';
 try{
   const model=createCar({model:selectedModel,color:paint,detail:'high'});
   model.traverse(o=>{o.userData={};});
   const data=await new GLTFExporter().parseAsync(model,{binary:true,onlyVisible:true});
   const url=URL.createObjectURL(new Blob([data],{type:'model/gltf-binary'}));
   const a=document.createElement('a');a.href=url;a.download=`AFTERLIGHT-${selectedModel}.glb`;a.click();
   setTimeout(()=>URL.revokeObjectURL(url),10000);disposeCar(model);toast('原创模型已导出，可在 Blender 等三维软件中打开。');
 }catch(error){console.error(error);toast('模型导出失败，请重试。');}finally{button.disabled=false;button.textContent='导出 GLB ↓';}
}

function bindUI(){
 $('play').onclick=$('nav-race').onclick=()=>{show('race-modal');drawMap($('brief-map'));};
 $('showroom').onclick=$('nav-studio').onclick=openStudio;
 $('studio-back').onclick=returnMenu;$('nav-settings').onclick=()=>show('settings-modal');
 $('start-race').onclick=setupRace;$('resume').onclick=togglePause;
 $('restart').onclick=$('result-retry').onclick=setupRace;
 $('quit').onclick=$('result-home').onclick=returnMenu;
 $('pause-settings').onclick=()=>show('settings-modal');
 document.querySelectorAll('[data-close]').forEach(e=>e.onclick=()=>show(e.dataset.close,false));
 document.querySelectorAll('[data-model]').forEach(e=>e.onclick=()=>selectCar(e.dataset.model));
 document.querySelectorAll('[data-paint]').forEach(e=>e.onclick=()=>setPaint(e.dataset.paint));
 document.querySelectorAll('[data-view]').forEach(e=>e.onclick=()=>setStudioView(e.dataset.view));
 $('export-model').onclick=exportModel;
 $('mode').onchange=()=>{$('difficulty').disabled=$('mode').value==='time';$('brief-distance').textContent=`${(track.length/1000).toFixed(2)} KM · ${$('mode').value==='time'?1:2} 圈`;};
 for(const [id,key] of [['quality','quality'],['sound-enabled','sound'],['voice-enabled','voice'],['dynamic-camera','dynamicCamera'],['show-fps','fps']])$(id).onchange=()=>{settings[key]=id==='quality'?$(id).value:$(id).checked;syncSettings();writeSave('afterlight.settings',settings);};
 window.addEventListener('keydown',e=>{
   if(['SELECT','INPUT','TEXTAREA'].includes(document.activeElement?.tagName))return;
   if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code))e.preventDefault();
   keys.add(e.code);if(e.repeat)return;
   if(e.code==='Escape'){if(!$('settings-modal').hidden)show('settings-modal',false);else if(!$('race-modal').hidden)show('race-modal',false);else if(state==='studio')returnMenu();else togglePause();}
   if(e.code==='KeyC'&&['racing','countdown'].includes(state))cycleCamera();
   if(e.code==='KeyR')resetPlayer();
   if(e.code==='KeyM'){settings.sound=!settings.sound;syncSettings();writeSave('afterlight.settings',settings);toast(settings.sound?'声音已开启':'声音已关闭',1.5);}
 });
 window.addEventListener('keyup',e=>keys.delete(e.code));
 window.addEventListener('blur',()=>{keys.clear();Object.keys(touch).forEach(k=>touch[k]=false);if(['racing','countdown'].includes(state))togglePause();});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&['racing','countdown'].includes(state))togglePause();});
 document.querySelectorAll('[data-touch]').forEach(button=>{
   button.addEventListener('pointerdown',e=>{e.preventDefault();button.setPointerCapture(e.pointerId);touch[button.dataset.touch]=true;});
   for(const event of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(event,()=>touch[button.dataset.touch]=false);
 });
 window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
 controls.addEventListener('start',()=>studioTransition=0);
}

function frame(now){
 requestAnimationFrame(frame);
 const dt=Math.min((now-lastFrame)/1000,.07);lastFrame=now;elapsed+=dt;menuTime+=dt;frameCount++;
 if(state==='racing'||state==='countdown'||state==='finishing'){
   accumulator+=dt;
   while(accumulator>=1/60){simulate(1/60);accumulator-=1/60;}
   updateMeshes(dt);raceCamera(dt);
   audio.update({speed:player.speed,throttle:player.throttle,brake:player.brake,slip:player.slip,model:selectedModel,dt});
 } else if(state==='menu')menuCamera(dt);
 else if(state==='finished')audio.update({speed:0,throttle:0,brake:0,slip:0,model:selectedModel,dt});
 else if(state==='studio'){
   if(studioTransition>0){camera.position.lerp(camPos,1-Math.exp(-6*dt));controls.target.lerp(camTarget,1-Math.exp(-6*dt));studioTransition-=dt;}
   controls.update();updateCar(heroCar,{steer:Math.sin(elapsed*.6)*.12,speed:0,brake:0,time:elapsed,dt});
   audio.update({speed:0,throttle:0,brake:0,slip:0,model:selectedModel,dt});
 }
 world.update(elapsed,dt);updateShadow();
 if(elapsed-lastHud>.09){lastHud=elapsed;if(player)updateHUD();if(state==='finishing')renderResults();}
 if(elapsed>toastUntil)show('toast',false);if(elapsed>eventUntil)show('event-banner',false);
 renderer.render(scene,camera);
 fpsElapsed+=dt;fpsFrames++;
 if(fpsElapsed>.7){$('fps').textContent=`${Math.round(fpsFrames/fpsElapsed)} FPS · ${renderer.info.render.calls} CALLS · ${(renderer.info.render.triangles/1000000).toFixed(2)}M TRI`;fpsElapsed=0;fpsFrames=0;}
}

async function boot(){
 try{
   renderer=new THREE.WebGLRenderer({canvas:$('scene'),antialias:true,powerPreference:'high-performance'});
   renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
   renderer.toneMappingExposure=1.05;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
   scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(43,innerWidth/innerHeight,.12,10000);
   controls=new OrbitControls(camera,$('scene'));controls.enabled=false;controls.enableDamping=true;controls.dampingFactor=.07;
   setQuality();await new Promise(requestAnimationFrame);
   track=createTrack();world=createWorld(scene,renderer,track);
   const pmrem=new THREE.PMREMGenerator(renderer);
   studioEnvironment=pmrem.fromScene(new RoomEnvironment(),.035).texture;
   coastEnvironment=scene.environment;coastBackground=null;
   try{
     const hdr=await new RGBELoader().loadAsync(`${import.meta.env.BASE_URL}environment/kloppenheim_06_puresky_2k.hdr`);
     hdr.mapping=THREE.EquirectangularReflectionMapping;
     coastEnvironment=pmrem.fromEquirectangular(hdr).texture;coastBackground=hdr;
     scene.environment=coastEnvironment;scene.background=hdr;
     world.skyMesh.visible=false;
   }catch(error){console.info('Using original procedural sky fallback.');}
   pmrem.dispose();scene.environmentIntensity=.8;
   studioFloor=new THREE.Group();studioFloor.name='studio-cyclorama';studioFloor.visible=false;
   const floor=new THREE.Mesh(new THREE.CircleGeometry(300,128),new THREE.MeshStandardMaterial({color:'#0b141a',roughness:.4,metalness:.3}));
   floor.rotation.x=-Math.PI/2;floor.position.y=-.012;floor.receiveShadow=true;studioFloor.add(floor);
   const ring=new THREE.Mesh(new THREE.RingGeometry(3.6,3.615,120),new THREE.MeshBasicMaterial({color:'#637575'}));ring.rotation.x=-Math.PI/2;ring.position.y=-.006;studioFloor.add(ring);scene.add(studioFloor);
   studioLighting=new THREE.Group();studioLighting.visible=false;
   const keyLight=new THREE.DirectionalLight('#ffe7ca',3.3);keyLight.position.set(4,7,4);keyLight.castShadow=true;
   keyLight.shadow.mapSize.set(2048,2048);Object.assign(keyLight.shadow.camera,{left:-8,right:8,top:8,bottom:-8,near:.1,far:30});keyLight.shadow.normalBias=.018;studioLighting.add(keyLight);
   const fill=new THREE.HemisphereLight('#aac8e2','#142025',.6);studioLighting.add(fill);scene.add(studioLighting);
   $('loading-status').textContent='抛光车身，准备第一缕阳光';await new Promise(requestAnimationFrame);
   selectCar('aurora');syncSettings();bindUI();
   $('track-length').textContent=`${(track.length/1000).toFixed(2)} KM 海岸环线`;
   $('brief-distance').textContent=`${(track.length/1000).toFixed(2)} KM · 2 圈`;
   state='menu';menuCamera(1,true);updateShadow();
   await renderer.compileAsync(scene,camera);renderer.render(scene,camera);
   $('loading').style.opacity='0';setTimeout(()=>show('loading',false),650);
   lastFrame=performance.now();requestAnimationFrame(frame);
   // Read-only telemetry for local smoke tests; no gameplay shortcuts in the shipped UI.
   window.__afterlight={get state(){return state;},get track(){return {length:track.length,width:track.width};},get telemetry(){return {state,raceTime,model:selectedModel,audio:{state:audio.context?.state||'not-started',voices:audio.voices.size},drivers:drivers.map(d=>({id:d.id,t:d.t,progress:d.progress,speed:d.speed,lap:d.lap,checkpoint:d.checkpoint,finishTime:d.finishTime,penalty:d.penalty})),drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,frameCount};}};
   if(import.meta.env.DEV&&new URLSearchParams(location.search).has('qa')){
     window.__afterlight.qaDrive=(seconds)=>{
       for(let tick=0;tick<seconds*60;tick++){
         if(state==='racing'){
           raceTime+=1/60;
           for(const d of drivers)stepDriver(d,aiControls(d,track,drivers,difficulty),track,1/60);
           resolveCars(drivers,track,1/60);
           for(const d of drivers){const event=updateRaceProgress(d,track,raceTime,totalLaps);if(d===player&&event==='finish'){finishRace();break;}}
         }else simulate(1/60);
       }
       updateMeshes(0);updateHUD();
       return window.__afterlight.telemetry;
     };
   }
 }catch(error){console.error(error);$('loading-status').textContent='场景未能启动：'+error.message;$('loading').innerHTML+='<p style="position:absolute;bottom:20%;left:15%;right:15%;text-align:center;font-size:12px">请使用支持 WebGL 2 的 Chrome 或 Edge，并开启硬件加速。刷新页面可重试。</p>';}
}
boot();
